<body>
  <div class="container">
    <?php echo validation_errors(); ?>
    <div class="card">
      <div class="card-header">
       <h1>Registration Form</h1>
      </div>
      <div class="card-body">
        <form action="<?php echo base_url() . "Midterm/update_submit/" . $userdata['user_id']; ?>" method="POST">
          <div class="form-group">
            <label for="firstname">First Name:</label>
            <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Firstname" value="<?php echo $userdata['Firstname']; ?>"  >
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="middlename">Middle Name:</label>
              <input type="text" class="form-control" id="middlename" name="middlename" placeholder="Middlename" value="<?php echo $userdata['Middlename']; ?>"  >
            </div>
            <div class="form-group col-md-6">
              <label for="lastname">Last Name:</label>
              <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Lastname" value="<?php echo $userdata['Lastname']; ?>"  >
            </div>
            <div class="form-group col-md-6">
              <label for="age">Age:</label>
              <input type="number" class="form-control" id="age" name="age" placeholder="Age" value="<?php echo $userdata['Age']; ?>"  >
            </div>
            <div class="form-group col-md-6">
              <label for="address">Address:</label>
              <input type="text" class="form-control" id="address" name="address" placeholder="Address" value="<?php echo $userdata['Address']; ?>"  >
            </div>
          </div>
          
          <button type="submit" class="btn btn-primary btn-lg">Update</button>
        </form>
      </div>
    </div>    
  </div>  
</body>
<body>