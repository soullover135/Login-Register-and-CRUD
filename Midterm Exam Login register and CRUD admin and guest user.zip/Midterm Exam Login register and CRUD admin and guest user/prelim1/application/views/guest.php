<body>
	<center>Welcome to guest page
		<h2>Click here</h2>
	<hr>
	<a href="<?php echo base_url() . "Midterm/register_submit"; ?>" class"btn btn-lg btn info">Register</a>
	</center>
</body>
