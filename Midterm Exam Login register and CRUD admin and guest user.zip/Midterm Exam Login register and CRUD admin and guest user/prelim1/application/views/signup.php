<body>
  <div class="container">
    <?php echo validation_errors(); ?>
    <div class="card">
      <div class="card-header">
       <h1>Registration Form</h1>
      </div>
      <div class="card-body">
        <form action="<?php echo base_url() . "Midterm/register_user"; ?>" method="POST">
          <div class="form-group">
            <label for="username">Username :</label>
            <input type="text" class="form-control" id="username" name="username" placeholder="Username">
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="user_password">Password :</label>
              <input type="text" class="form-control" id="user_password" name="user_password" placeholder="Middlename">
            </div>
            <div class="form-group col-md-6">
              <label for="user_type">User Type :</label>
              <input type="text" class="form-control" id="user_type" name="user_type" placeholder="Lastname">
            </div>
          </div>
          
          <button type="submit" class="btn btn-primary btn-lg">Register</button>
        </form>
      </div>
    </div>    
  </div>  
</body>