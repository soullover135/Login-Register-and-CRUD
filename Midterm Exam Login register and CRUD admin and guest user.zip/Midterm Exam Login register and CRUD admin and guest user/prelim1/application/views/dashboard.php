<body><br>
  <div class="container">
    <p></p>
    <div class="card">
      <div class="card-header">
        User's List
      </div>
      <div class="card-body">
        <table class="table">
          <thead class="thead-dark">
            <tr>
              <th scope="col">User ID</th>
              <th scope="col">Fist Name</th>
              <th scope="col">Middle Name</th>
              <th scope="col">Last Name</th>
              <th scope="col">Age</th>
              <th scope="col">Address</th>
              <th scope="col">Controls</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($users as $k => $user){ ?>
              <tr>
                <th scope="row"><?php echo $user['user_id']; ?></th>
                <td><?php echo $user['Firstname']; ?></td>
                <td><?php echo $user['Middlename']; ?></td>
                <td><?php echo $user['Lastname']; ?></td>
                <td><?php echo $user['Age']; ?></td>
                <td><?php echo $user['Address']; ?></td>
                <td><a href="<?php echo base_url()."Midterm/update_user/".$user['user_id'];?>" class="btn btn-warning">Edit</a> <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal"  class="btn btn-danger">Delete</button></td>
              </tr>
          <?php } ?>
          </tbody>
        </table>
      </div>  
    </div>
  </div>

  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are you sure you want to delete?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        This operation cannot be undone.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <a href="<?php echo base_url()."Midterm/delete_user/".$user['user_id']; ?>" class="btn btn-danger">Confirm</a>
      </div>
    </div>
  </div>
</div>
</body>






