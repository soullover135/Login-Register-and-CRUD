<body><br>
	<div class="container col-3">
		<?php
			if(isset($error_message))
			{
		?>		
				<div class="alert alert-warning alert-dismissible fade show" role="alert">

		<?php		echo $error_message;   ?>
		
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>
		<?php	
			}
		?>

		<div class="card" >
		  <div class="card-header">
		    Login Form
		  </div>
		  <div class="card-body">
			<form action="<?php echo base_url()."Midterm/user_auth"; ?>" method="POST">
			  <div class="form-group">
			    <label for="username">Username</label>
			    <input type="text" class="form-control" id="username" name="username" placeholder="Enter Username" required>
			  </div>
			  <div class="form-group">
			    <label for="userpass">Password</label>
			    <input type="password" class="form-control" id="userpass" name="userpass" placeholder="Password" required>
			  </div>
			  <button type="submit" class="btn btn-primary">Login</button>
			</form>
		  </div>
		  <a href="<?php echo base_url() . "Midterm/register_user"; ?>" class"btn btn-lg btn info">Signup</a>
		</div>	
	</div>
</body>