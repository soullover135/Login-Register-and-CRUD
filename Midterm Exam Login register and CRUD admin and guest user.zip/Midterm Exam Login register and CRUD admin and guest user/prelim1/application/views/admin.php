<body>
	<center>Welcome to admin page
		<h2>Click here</h2>
	<hr>
	<a href="<?php echo base_url() . "Midterm/register_submit"; ?>" class"btn btn-lg btn info">Add User Info</a>
	<a href="<?php echo base_url() . "Midterm/user_info"; ?>" class"btn btn-lg btn info">View User Info</a>
	</center>
</body>
