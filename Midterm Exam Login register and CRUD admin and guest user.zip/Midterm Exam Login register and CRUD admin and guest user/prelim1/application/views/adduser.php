<body>
  <div class="container">
    <?php echo validation_errors(); ?>
    <div class="card">
      <div class="card-header">
       <h1>Registration Form</h1>
      </div>
      <div class="card-body">
        <form action="<?php echo base_url() . "Midterm/register_submit"; ?>" method="POST">
          <div class="form-group">
            <label for="firstname">First Name:</label>
            <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Firstname">
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="middlename">Middle Name:</label>
              <input type="text" class="form-control" id="middlename" name="middlename" placeholder="Middlename">
            </div>
            <div class="form-group col-md-6">
              <label for="lastname">Last Name:</label>
              <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Lastname">
            </div>
            <div class="form-group col-md-6">
              <label for="age">Age:</label>
              <input type="number" class="form-control" id="age" name="age" placeholder="Age">
            </div>
            <div class="form-group col-md-6">
              <label for="address">Address:</label>
              <input type="text" class="form-control" id="address" name="address" placeholder="Address">
            </div>
          </div>
          
          <button type="submit" class="btn btn-primary btn-lg">Register</button>
        </form>
      </div>
    </div>    
  </div>  
</body>