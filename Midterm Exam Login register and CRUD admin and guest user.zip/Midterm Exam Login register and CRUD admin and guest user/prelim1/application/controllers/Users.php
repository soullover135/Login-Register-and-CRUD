<!-- <?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {


	public function index()
	{
		$this->load->model('user_model');
		$data['users'] = $this->user_model->get_users();

		$this->load->view('templates/header');
		$this->load->view('dashboard',$data);
		$this->load->view('templates/footer');
	}

	// public function user_type()
	// {
		

	// 	$this->load->view('templates/header');
	// 	$this->load->view('adduser',$data);
	// 	$this->load->view('templates/footer');
	// }


	public function register_user()
	{
		$this->load->model('user_model');
		$data['usertype'] = $this->user_model->get_user_type();

		$this->load->view('templates/header');
		$this->load->view('adduser',$data);
		$this->load->view('templates/footer');
	}


	public function register_submit()
	{
		$data = $this->input->post();
		

		$this->form_validation->set_rules('username', 'Username', 'required|is_unique[users.user_name]', array('is_unique' =>"Username already exists!"));
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('confpass', 'Password Confirmation', 'required|matches[password]');
		$this->form_validation->set_rules('usertype', 'User Type', 'required');

        if ($this->form_validation->run() == FALSE)
        {
			$this->load->view('templates/header');
			$this->load->view('adduser');
			$this->load->view('templates/footer');              
        }
        else
        {
            $this->load->model('user_model');
            $result = $this->user_model->add_user($data);
            if($result > 0){
            	redirect("users");
            }
        }

	}	

	public function update_user($id)
	{
		$this->load->model('user_model');
		$old_data['userdata'] = $this->user_model->get_user($id);

		$this->load->view('templates/header');
		$this->load->view('update_form',$old_data);
		$this->load->view('templates/footer');

	}	

	public function update_submit($id)
	{
		$data = $this->input->post();
		$data['userid'] = $id;
		

		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('confpass', 'Password Confirmation', 'required|matches[password]');
		$this->form_validation->set_rules('usertype', 'User Type', 'required');

        if ($this->form_validation->run() == FALSE)
        {
           $this->update_user($id);
        }
        else
        {
            $this->load->model('user_model');
            $result = $this->user_model->update_user($data);
            if($result > 0){
            	redirect("users");
            }
        }

	}

public function delete_user($id)
	{
		$this->load->model('user_model');
		$result = $this->user_model->delete_user($id);
	    if($result > 0){
        	redirect("users");
        }
}

}


 -->