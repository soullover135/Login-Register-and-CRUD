<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Midterm extends CI_Controller {

public function register()
	{

		$this->load->view('templates/header');
		$this->load->view('adduser');
		$this->load->view('templates/footer');
	}

public function index()
	{

		$this->load->view('templates/header');
		$this->load->view('login');
		$this->load->view('templates/footer');
	}
	// public function user_type()
	// {
		

	// 	$this->load->view('templates/header');
	// 	$this->load->view('adduser',$data);
	// 	$this->load->view('templates/footer');
	// }
public function admin()
	{
		$data['user'] = $this->session->userdata('username');
		
		$this->load->view('templates/header');
		$this->load->view('admin',$data);
		$this->load->view('templates/footer');
	}

public function guest()
	{
		$data['user'] = $this->session->userdata('username');
		
		$this->load->view('templates/header');
		$this->load->view('guest',$data);
		$this->load->view('templates/footer');
	}

public function sub_admin()
	{
		$data['user'] = $this->session->userdata('username');
		
		$this->load->view('templates/header');
		$this->load->view('sub_admin',$data);
		$this->load->view('templates/footer');
	}

	public function user_list()
	{
		$this->load->model('paul');
		$data['users'] = $this->paul->get_users();

		$this->load->view('templates/header');
		$this->load->view('dashboard',$data);
		$this->load->view('templates/footer');
	}

	public function user_info()
	{
		$this->load->model('paul');
		$data['users'] = $this->paul->get_users();

		$this->load->view('templates/header');
		$this->load->view('user_info',$data);
		$this->load->view('templates/footer');
	}

	public function 	user_auth()
	{
		$logindata = $this->input->post();	
		
		$this->load->model('paul');
		$response = $this->paul->user_auth($logindata);

		if(!is_null($response))
		{
			$sess_data = array(
							'user_id' => $response['user_id'],
							'username' => $response['username'],
							'user_type' => $response['user_type']
						);

			$this->session->set_userdata($sess_data);
			$this->redirectpage();

		}else{
			$data['error_message'] = "Invalid Username or Password!";

			$this->load->view('header');
			$this->load->view('login',$data);
			$this->load->view('footer');
		}
	}

	private function redirectpage()
	{
		

		if($this->session->userdata('user_type') == 'Admin')
		{
			
			redirect('Midterm/admin').$this->session->userdata('username');
			/*echo "<center><h1>Welcome, This is Admin Page</h3>";
			echo "<center><p> <h1>Welcome ".$this->session->userdata('username')."</p>";*/

		}else if($this->session->userdata('user_type') == 'Guest')
		{

			redirect('Midterm/user_list').$this->session->userdata('username');
		}else if($this->session->userdata('user_type') == 'user')
		{

			redirect('Midterm/user_list').$this->session->userdata('username');
		}else {

			
		}
		

	}



	public function register_submit()
	{
		$data = $this->input->post();
		

		$this->form_validation->set_rules('firstname', 'Firstname', 'required');
		$this->form_validation->set_rules('middlename', 'Middlename', 'required');
		$this->form_validation->set_rules('lastname', 'Lastname', 'required');
		$this->form_validation->set_rules('age', 'Age', 'required');
		$this->form_validation->set_rules('address', 'Address', 'required');

        if ($this->form_validation->run() == FALSE)
        {
			$this->load->view('templates/header');
			$this->load->view('adduser');
			$this->load->view('templates/footer');              
        }
        else
        {
            $this->load->model('paul');
            $result = $this->paul->add_user($data);
            if($result > 0){
            	redirect("Midterm/register_submit");
            }
        }

	}	

	public function register_user()
	{
		$data = $this->input->post();
		

		$this->form_validation->set_rules('username', 'username', 'required');
		$this->form_validation->set_rules('user_password', 'user_password', 'required');
		$this->form_validation->set_rules('user_type', 'user_type', 'required');

        if ($this->form_validation->run() == FALSE)
        {
			$this->load->view('templates/header');
			$this->load->view('signup');
			$this->load->view('templates/footer');              
        }
        else
        {
            $this->load->model('paul');
            $result = $this->paul->add_userlogin($data);
            if($result > 0)
            	redirect("Midterm/register_user");
            }
        }

	

	

	public function update_user($id)
	{
		$this->load->model('paul');
		$old_data['userdata'] = $this->paul->get_user($id);

		$this->load->view('templates/header');
		$this->load->view('update_form',$old_data);
		$this->load->view('templates/footer');

	}	

	public function update_submit($id)
	{
		$data = $this->input->post();
		$data['userid'] = $id;
		

		$this->form_validation->set_rules('firstname', 'Firstname', 'required');
		$this->form_validation->set_rules('middlename', 'Middlename', 'required');
		$this->form_validation->set_rules('lastname', 'Lastname', 'required');
		$this->form_validation->set_rules('age', 'Age', 'required');
		$this->form_validation->set_rules('address', 'Address', 'required');

        if ($this->form_validation->run() == FALSE)
        {
           $this->update_user($id);
        }
        else
        {
            $this->load->model('paul');
            $result = $this->paul->update_user($data);
            if($result > 0){
            	// redirect("paul");
            	return $this->user_list();
            }
        }

	}

public function delete_user($id)
	{
		$this->load->model('paul');
		$result = $this->paul->delete_user($id);
	    if($result > 0){
        	// redirect("user_list");
        	return $this->user_list();
        }
}



}
