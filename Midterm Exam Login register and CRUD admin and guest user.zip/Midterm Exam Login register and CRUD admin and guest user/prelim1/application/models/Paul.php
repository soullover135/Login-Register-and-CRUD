<?php
class paul extends CI_Model {

    public function __construct()
    {
            $this->load->database();
    }

    public function get_users()
    {
    	$query = $this->db->get('users');
    	return $query->result_array();
    }
    public function get_user_type()
    {
        $query = $this->db->get('usertype');
        return $query->result_array();
    }



    public function add_user($data)
    {
    $userdata = array(
        'Firstname' => $data['firstname'], 
    	'Middlename' => $data['middlename'], 
    	'Lastname' => $data['lastname'],
        'Age' => $data['age'],
        'Address' => $data['address']);

    	$this->db->insert('users',$userdata);
    	return $this->db->affected_rows();
    }    

    public function add_userlogin($data)
    {
    $userdata = array(
        'username' => $data['username'], 
        'user_password' => $data['user_password'], 
        'user_type' => $data['user_type']);

        $this->db->insert('login',$userdata);
        return $this->db->affected_rows();
    }    

      public function user_auth($userdata){
        $querydata = array(
                        'username' => $userdata['username'],
                        'user_password' => $userdata['userpass']
                    );

        $query = $this->db->get_where('login', $querydata);
        $result = $query->result_array();

        if(count($result) > 0){
            return $result[0];
        }else{
            return null;
        }
    }


    public function get_user($id)
    {  
        $this->db->where('user_id', $id);
        $query = $this->db->get('users');
        $result = $query->result_array();
        return $result[0];
    }

    public function update_user($data)
    {
        $id = $data['userid'];
        $userdata = array(
                        'Firstname' => $data['firstname'], 
                        'Middlename' => $data['middlename'], 
                        'Lastname' => $data['lastname'],
                        'Age' => $data['age'], 
                        'Address' => $data['address']
                    );
        $this->db->set($userdata);
        $this->db->where('user_id', $id);
        $this->db->update('users');
        return $this->db->affected_rows();
    }

    public function delete_user($id)
    {
        $this->db->where('user_id', $id);
        $query = $this->db->delete('users');
        return $this->db->affected_rows();
    }


}