<?php
class User_model extends CI_Model {

    public function __construct()
    {
            $this->load->database();
    }

    public function get_users()
    {
    	$query = $this->db->get('users');
    	return $query->result_array();
    }

    public function get_user_type()
    {
    	$query = $this->db->get('usertype');
    	return $query->result_array();
    }


    public function add_user($data)
    {
    $userdata = array(
        'user_name' => $data['username'], 
    	'user_password' => $data['password'], 
    	'user_type' => $data['usertype']);

    	$this->db->insert('users',$userdata);
    	return $this->db->affected_rows();
    }    

    public function get_user($id)
    {  
        $this->db->where('user_id', $id);
        $query = $this->db->get('users');
        $result = $query->result_array();
        return $result[0];
    }

    public function update_user($data)
    {
        $id = $data['userid'];
        $userdata = array(
                        'user_name' => $data['username'], 
                        'user_password' => $data['password'], 
                        'user_type' => $data['usertype']
                    );
        $this->db->set($userdata);
        $this->db->where('user_id', $id);
        $this->db->update('users');
        return $this->db->affected_rows();
    }

    public function delete_user($id)
    {
        $this->db->where('user_id', $id);
        $query = $this->db->delete('users');
        return $this->db->affected_rows();
    }


}
